# HR KPI Dashboard — Gap Analysis & What Changed

Source reviewed: `KPI Dashboard.pbip` (7 pages, SharePoint site `nestle.sharepoint.com/teams/sanjay/kpi`,
lists HR_KPI_Assignments, HR_KPI_Progress, HR_Employees, HR_KPI_Reminders).

## 0. v4 refactor (from the Power App file)
The queries now use the exact list columns of the HR KPI Hub app (display names and internal field_N names),
follow the app's rules (MeasureType, Direction, Frequency, required month, status thresholds), ignore Returned updates
and Closed assignments, read the 'yyyy-mm' Period key to avoid UTC date shifts, and the model has no calculated columns.

## 1. The data connection — kept
The SharePoint connection, the list fallbacks and the column-detection helpers (fnList, fnCol, fnVal…) work well
and were kept unchanged. Only the shaping on top of them was extended.

## 2. Calculation errors in the old file (numbers were wrong)
| # | Old behaviour | Why it is wrong | Fixed by |
|---|---|---|---|
| 1 | "This Month Actual" = average of **all** progress values on the single latest date | Mixes units (hours + % + headcount) and ignores every other day of the month | Month actual per KPI, for the whole calendar month |
| 2 | "Annual Target" = `AVERAGE(Target)` across KPIs | Averages unrelated targets | Targets per KPI, converted by frequency |
| 3 | Yearly requirement = target × 12 | Treats every target as monthly, even when the table header said "Annual Target" (12× inflation) | Target × periods per year (weekly 52, monthly 12, quarterly 4…) |
| 4 | "Elapsed Months" = number of distinct update **dates** | 30 daily updates = "30 months" | Calendar months Jan → reporting month |
| 5 | "YTD Average Actual" = average of all progress ever | Not year-to-date, not year-filtered | Jan–reporting month window |
| 6 | Projection = latest single value × remaining months | One outlier drives the forecast | Average monthly pace × remaining months |
| 7 | Achievement = latest value ÷ target | A weekly figure compared with a monthly/annual target | Same-period comparison |
| 8 | No idea of % / rate KPIs or "lower is better" | Attrition 3% vs target 5% showed as 60% (bad) | Aggregation (Sum / Average / Latest) and Direction (Higher / Lower) |
| 9 | KPI Weight imported as text, never used | Important KPIs count the same as minor ones | Numeric weight in every score |
| 10 | Custom theme file never registered | Theme ignored | Theme registered |
| 11 | Calendar related to Progress, no month selector | No way to look at "last month" or any past month | Reporting-month slicer + independent trend axis |
| 12 | "No Update" based on 35 days since any update | Quarterly / annual KPIs flagged as missing | Due-date logic by frequency |

## 3. Missing analysis areas (HR-director view)
- **Month ⇄ Year in one glance** — the core question "what did this month do to the year?" had no answer.
  Now every KPI shows: month result, year progress, **change in year progress caused by this month (pts)**,
  where it should be by now (pace marker), forecast to December and the monthly run-rate still needed.
- **Portfolio score** — one weighted score for the company, a department, a category or a person.
- **Status distribution month vs year** — how many KPIs are on track / near / behind now vs year-to-date.
- **People view** — employee ranking by forecast, with missing submissions next to performance.
- **Submission discipline** — expected vs received updates for the month, compliance trend, who is late,
  last reminder — so data gaps are not mistaken for poor performance.
- **KPI deep dive** — one KPI in real units (hours, people, %), monthly actual vs target trend, submission history with comments.
- **Definitions page** — every number explained, so the dashboard can be trusted without the developer.

## 4. Still not possible with the current SharePoint data (recommended additions)
| Add to list | Column | Unlocks |
|---|---|---|
| HR_KPI_Assignments | `StartDate` | Correct pro-rating for KPIs assigned mid-year |
| HR_KPI_Assignments | `Unit` | Units on every number ("hrs", "%", "people") |
| HR_KPI_Assignments | `AggregationType` (Sum / Average / Latest) | Exact roll-up instead of name-based detection |
| HR_KPI_Assignments | `Direction` (Higher / Lower) | Correct scoring of attrition, absenteeism, cost KPIs |
| HR_KPI_Progress | `ReviewStatus` (Pending / Approved / Rejected) | Only approved values counted |
| HR_Employees | `Department`, `Manager` | Department page and manager roll-ups |
The dashboard picks these columns up automatically after a refresh — no Power BI changes needed.

## 5. Design
California Citrus & Coastal Teal: ivory canvas #FFFBF5, white 16 px cards with #FDE68A borders and a 6 % tangerine
ambient shadow, Tangerine #F97316 for "this month", Coastal Teal #0D9488 for "year", Mango #FBBF24 for targets,
Charcoal Navy #0F172A text, beige #F3E8D6 gridlines, Segoe UI Bold 28 pt KPI values.

Power BI Desktop September 2023 cannot draw gradient-filled spline areas, and the "new card" visual was only a preview then.
The three headline cards with pill badges and the gradient spline trend are therefore drawn as SVG images by DAX measures
(`5 SVG visuals` folder) — they render in your version and refresh with the data.
The GMV `$#,##0.00` tip does not apply (there is no sales value in HR data); the same idea is used for variances:
positive changes are coloured teal and negative ones tangerine.
