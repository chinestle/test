# NestElevate v2 – Power App redesign + Power BI training dashboard

Package contents

| File / folder | What it is |
|---|---|
| `Nest Elevate v2.msapp` | Your Power App with the new UI/UX and logic fixes. Same data sources, same flows, same screen names. |
| `Power BI/Nest Elevate Training Dashboard.pbip` | Power BI project (2023 "developer mode" format). Open this file. |
| `Power BI/…Dataset/model.bim` | Semantic model: Power Query, relationships and 30 DAX measures |
| `Power BI/…Report/report.json` | 5-page report in the Azure & Coral design |
| `Power BI/Rebuild kit/` | All M queries, DAX measures, the 2026 training plan (CSV) and the theme JSON, in case you need to rebuild by hand |
| `Previews/` | Screenshots: the new app screens and the dashboard pages (dashboard rendered with your sample data) |

---

## 1. Requirements found in the app

**What the app does**: `Home → Main menu → 6 workspaces`

| Workspace | What it does | Data |
|---|---|---|
| New training allocation → *One training → many employees* | Pick a Training Map module, a plan date and employees, then Patch to `nelevate_TrainingAllocation` (status *Pending*) | Training Map, Employee Master |
| New training allocation → *One employee → many trainings* | Same, the other way round. Also *assign the full Training Map* | same |
| New training allocation → *Automatic allocation* | Upload the Excel template, then the **TrainingModuleAllocations** flow creates allocations. *Export allocated file* runs **TrainingExporttoExcel** | Excel → flow → SharePoint |
| Module completion | Upload the completion Excel, then the **TrainingModuleCompletionUpdate** flow sets Completed / Completed On / marks / skill levels | Excel → flow → SharePoint |
| Add new training / Edit training modules | Maintain the `nelevate_TrainingMap` catalogue | SharePoint |
| Edit training allocation | Find and edit one allocation | SharePoint |
| Reports | Opens the Power BI report | Power BI |

Upload columns, from *Data Upload.xlsx*: Employee Number, Allocated Module, Time Duration, Assigned Date, Completed On, Plan Date, Department, Section, Resource Person, Training Category, Mandatory Status, Training Pillar, Existing Skill Level, Completion Status, Evaluation Marks, New Skill Level.

**Analysis levels for the dashboard**: Factory (Kurunegala) → Department → Section → Employee. The 2026 plan from the tracking workbook (BC and WC mandatory lists, PG I and PG II section programmes) is used as the benchmark.

## 2. Power App: what changed

**Design system** (it matches the dashboard): Coastal Breeze background `#F0F9FF`, white cards with 16 px radius and `#BAE6FD` border, Mediterranean Azure `#0284C7` primary, Sunlit Coral `#FB923C` accent, navy `#0C4A6E` headings, Segoe UI throughout.

* **One header on every screen**: logo, product name, breadcrumb, signed-in user, Back (on sub-screens) and Home.
* **Landing screen**: split hero, with a branded panel on the left and the value proposition and a "Get started" call to action on the right.
* **Menu**: 6 cards in a 3 × 2 grid. Each card has an icon, a title, a one-line description and an "Open →" link. The whole card is clickable and shows a hover state.
* **Allocation chooser**: 3 cards, each with a coloured icon badge and a description.
* **Allocation screens**: a two-pane layout. The list is on the left, with selection highlight and subtitles showing code, hours and category. The details panel is on the right. The selected item is echoed in the panel. Assign buttons stay disabled until the inputs are valid. Bulk actions are separated out and labelled.
* **Upload screens**: three numbered steps (download, attach, upload) and a large dashed drop zone. The button shows *"Processing… please wait"* and blocks double-clicks while the flow runs. The attachment clears after a successful upload. A column-header hint is shown.
* **Forms**: 8 px rounded inputs with an azure focus ring, field captions in Semibold, and a *Clear form* button.

**Logic fixes** (these improve the Power BI data quality):

1. *Edit training allocation*: the form opened **the first allocation of the employee**, not the one you selected. It now opens `Gallery1_2.Selected`.
2. *Edit training allocation*: the **Update button had no action**. It now runs `SubmitForm(Form2)` and shows success/failure messages.
3. *Edit training allocation*: the employee filter listed duplicate employee numbers. It now uses `Distinct(...)`.
4. *One training → many*: it saved the module **code** (`Title`) as *Allocated Module*, while the other screens save the module **name**. It now saves `'Training Name'`, so modules group correctly in Power BI. ⚠ If you intentionally store codes, revert this one line in `Button3` and `Button3_1`.
5. *Assign to all* now uses the same +5:30 time-zone correction as the other buttons, so dates no longer shift by a day.
6. Add/Edit Training Map: success and error notifications were added. The form no longer resets when a save fails.

**Import**: Power Apps → *Apps* → **Import canvas app** (or open Studio → *Open* → browse to the .msapp) → **Save** → **Publish**. Re-confirm connections to SharePoint and the 3 flows if prompted.

## 3. Make an upload update Power BI automatically

The app never writes to Power BI directly. Every allocation and every upload goes into the SharePoint list **nelevate_TrainingAllocation**, and the dashboard reads that list. To make the dashboard refresh right after an upload:

1. Publish the dashboard (step 4).
2. In Power Automate, open **TrainingModuleAllocations** and **TrainingModuleCompletionUpdate**.
3. After the step that writes the rows to SharePoint, add the **Power BI → Refresh a dataset** action. Choose your workspace and *Nest Elevate Training Dashboard*.
4. Save. From now on: upload in the app → flow updates SharePoint → flow triggers a refresh → the dashboard shows the new numbers within a few minutes. The time is shown under the page buttons as "Data refreshed …".
5. Optional: add a scheduled refresh in the Power BI service (for example 07:30 and 13:30) as a safety net.

Then update the **Reports** card URL in the app (`Button2_6.OnSelect`) to the new report link.

## 4. Open the Power BI project (Desktop 2023)

1. You need **Power BI Desktop June 2023 (2.118) or later**. In *File → Options → Preview features*, tick **"Power BI Project (.pbip) save option"** and restart. (PBIP does not exist in releases before June 2023.)
2. Keep the folder structure as-is and open **`Nest Elevate Training Dashboard.pbip`**.
3. Go to *Transform data → Edit parameters*:

| Parameter | Default | Use |
|---|---|---|
| `SourceMode` | **SharePoint List** | Live mode: reads `nelevate_TrainingAllocation` + `Employee Master` (names and designations) |
| `SharePointSiteUrl` | https://nestle.sharepoint.com/teams/sanjay | |
| `AllocationListName` | nelevate_TrainingAllocation | |
| `EmployeeListName` | Employee Master | |
| `ExcelFileLocation` | C:\NestElevate\2025.12.17 Data Upload - Upload.xlsx | Used only when `SourceMode = Excel File` (test with an upload file). It also accepts an https SharePoint file URL |
| `FactoryName` | Kurunegala | Label used when the source has no Factory column. Add a *Factory* column later for multi-factory roll-up |

4. **Refresh**. Sign in with your Nestlé *Organizational account* when asked for SharePoint.
5. *File → Save as → Power BI file (.pbix)* if you also want a single file, then **Publish**.
6. In the service, *dataset settings → Data source credentials → SharePoint → OAuth2*. Leave `SourceMode` on *SharePoint List* for scheduled refresh. Local Excel paths would need a gateway.

**Data cleansing built into Power Query**: trims spaces ("Agri Services ", "VBD "), merges *Production Group 01/02* into *Production Group I/II*, reads mixed date text such as "7/8/2025 & 7/9/2025", treats blank status as *Pending*, expands codes (CM → Common Module, AM → Autonomous Maintenance, QA → Quality Assurance …), and handles SharePoint internal names (field_3 …) and choice columns.

## 5. Dashboard design (Azure & Coral)

Canvas `#F0F9FF`. White cards with 16 px radius, `#BAE6FD` border and a 5 % azure glow. Azure bars, 3 px smooth coral lines, cobalt benchmarks. Your hospitality spec is mapped to training as follows:

| Spec | In this dashboard |
|---|---|
| Columns = Occupancy % (azure, left axis 0–100 %) | **Completion %** (left axis fixed at 0–100 %) |
| Line = ADR in USD (coral, right axis) | **Training hours delivered**, or **Avg hours per employee** (right axis) |
| Benchmark markers (cobalt) | **Target 90 %** dashed reference line, plus **2026 plan hours per employee** as cobalt diamond markers (Section page) |

**Pages** (navigation buttons on every page; slicers synced across pages):

1. **Factory overview**: KPIs, monthly combo, completion by department, hours by TPM pillar, completed vs pending by category.
2. **Department analysis**: department combo, department × pillar completion heat-map, top modules, mandatory vs common hours.
3. **Section analysis**: section scorecard combo against the 2026 plan, league table, and the 2026 plan list for the selected section.
4. **Employee analysis**: searchable employee slicer, employee scorecard (click a row to see that person's training history), hours-band distribution, overdue and on-time KPIs.
5. **Modules & trainers**: module performance, top resource persons, pillar × category heat-map.

**Key measures** (`_Measures` table): Total Allocations, Completed, Pending, Overdue, Completion %, Mandatory Completion %, On-Time %, Target 90 %, Training Hours Delivered (by plan date or by completion date), Employees Allocated/Trained, Fully Completed Employees, Avg Hours per Employee, Plan Hours per Employee (2026), Plan Modules (2026), Avg Evaluation Marks, Avg Skill Uplift.

**Notes**

* The sample upload file has every row marked *Completed* and no marks or skill levels. The previews therefore show 100 % and blank marks. Live SharePoint data with *Pending* allocations will show the real gaps.
* Desktop 2023 line markers are solid. The "white centre with coral ring" marker style only arrived in later Desktop builds, so markers are solid coral circles here.
* The 2026 plan is embedded in the model (table *TrainingPlan*). To change it: *Transform data → TrainingPlan → Source* (gear icon), which opens the editable table. The original is in `Rebuild kit/TrainingPlan_2026.csv`.
* Target completion (90 %) is the measure `Target Completion %`. Change it in one place.
